(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
var fastn = require('fastn');
var getComponentConfig = require('fastn/getComponentConfig');
var fancyProps = require('fancy-props');
var textComponent = require('./text');
var registerRenderer = require('./registerRenderer');
var insertIntoParent = require('./insertIntoParent');

function renderDomComponent(component){
    component.element = component.element || document.createElement(component.tagName);
    component.on('insertElement', (parentComponent, index) => insertIntoParent(component, parentComponent, index));
    component.on('removeElement', (parentComponent, index) => component.element && component.element.remove());
    component.on('newListener', (eventName, handler) => addEventListener(component, eventName, handler));
    component.on('removeListener', (eventName, handler) => removeEventListener(component, eventName, handler));

    Object.keys(component._events).forEach(eventName => {
        var handlers = [component._events[eventName]].flat()
        handlers.forEach(handler => addEventListener(component, eventName, handler));
    });

    var componentConfig = getComponentConfig(component);
    var componentPropertiesConfig = componentConfig.properties;

    Object.keys(componentConfig.properties).forEach(key => {
        updateProperty(component, key, component[key]);
        component.on(key, value => updateProperty(component, key, value));
    });
}

function updateProperty(component, key, value){
    var element = component.element;

    var isProperty = key in element || !('getAttribute' in element),
        fancyProp = component._fancyProps && component._fancyProps(key) || fancyProps[key],
        previous = fancyProp ? fancyProp(element) : isProperty ? element[key] : element.getAttribute(key);

    if(!fancyProp && !isProperty && value == null){
        value = '';
    }

    if(value !== previous){
        if(fancyProp){
            fancyProp(element, value);
            return;
        }

        if(isProperty){
            element[key] = value;
            return;
        }

        if(typeof value !== 'function' && typeof value !== 'object'){
            element.setAttribute(key, value);
        }
    }
}

function addEventListener(component, eventName, handler){
    var componentConfig = getComponentConfig(component);
    componentConfig.eventHandlerMap = componentConfig.eventHandlerMap || new WeakMap();

    if(component.element && `on${eventName}` in component.element && !componentConfig.eventHandlerMap.has(handler)){
        function domHandler(event){
            handler(event, componentConfig.state, component);
        }

        componentConfig.eventHandlerMap.set(handler, domHandler);
        component.element.addEventListener(eventName, domHandler);
    }
}

function removeEventListener(component, eventName, handler){
    var componentConfig = getComponentConfig(component);
    componentConfig.eventHandlerMap = componentConfig.eventHandlerMap || new WeakMap();

    if(component.element && `on${eventName}` in component.element){
        var domHandler = componentConfig.eventHandlerMap.get(handler);
        if(domHandler){
            component.element.removeEventListener(eventName, domHandler);
            componentConfig.eventHandlerMap.delete(handler);
        }
    }
}

function domComponent(tag, settings, ...children){
    if(typeof settings === 'string' || typeof settings === 'number' || fastn.is.attachable(settings)){
        children.unshift(settings);
        settings = {};
    }

    children = children.reduce((initialisedChildren, child) => {
        if(child == null || child === false){
            return initialisedChildren;
        }
        
        if(fastn.is.component(child)){
            initialisedChildren.push(child);
        } else {
            initialisedChildren.push(textComponent({
                text: child
            }));
        }

        return initialisedChildren;
    }, []);

    var component = fastn.is.component(tag) ? tag : fastn.component(settings, children);

    fastn.setProperty(component, 'tagName', {
        value: tag || component.tagName
    });

    component.render = function(renderers){
        if(component.element){
            return;
        }
        var componentConfig = getComponentConfig(component);
        renderers = registerRenderer(renderers, 'dom', renderDomComponent);
        renderers.dom(component);
        componentConfig.renderers = renderers;

        component.emit('render', component, renderers);

        fastn.component.getChildren(component).forEach((child, childIndex) => {
            child.render(renderers);
            child.emit('insertElement', component, childIndex);
        });

        return component;
    }

    return component;
}

module.exports = domComponent;
},{"./insertIntoParent":2,"./registerRenderer":7,"./text":8,"fancy-props":4,"fastn":16,"fastn/getComponentConfig":15}],2:[function(require,module,exports){
var getComponentConfig = require('fastn/getComponentConfig');
var fastn = require('fastn');
var INDEX_CACHE = Symbol('indexCache');
var clearCache = [];

setInterval(() => {
    if(clearCache.length){
        clearCache.forEach(component => component[INDEX_CACHE] = null);
        clearCache = [];
    }
});

function getLastRenderChild(component){
    var children = fastn.component.getChildren(component);
    var lastChild = children[children.length - 1];

    if(!lastChild){
        return;
    }

    if(Array.isArray(lastChild.element)){
        return getLastRenderChild(component);
    }

    return lastChild;
}

function getPreviousRenderSibling(component){
    var parent = fastn.component.getParent(component);
    var siblings = fastn.component.getChildren(parent);
    var index = siblings.indexOf(component);
    var previousSibling = fastn.component.getChildren(parent)[index - 1];

    if(previousSibling && Array.isArray(previousSibling.element)){
        return getLastRenderChild(previousSibling);
    }

    return previousSibling
}

function getAbsoluteIndex(component){
    if(component[INDEX_CACHE]){
        return component[INDEX_CACHE];
    }

    clearCache.push(component);

    var parent = fastn.component.getParent(component);

    if(!parent){
        return component[INDEX_CACHE] = 0;
    }

    var relativeIndex = fastn.component.getChildren(parent).indexOf(component);

    if(relativeIndex === 0 && !Array.isArray(parent.element)){
        return component[INDEX_CACHE] = relativeIndex;
    }

    var previousSibling = getPreviousRenderSibling(component);

    if(previousSibling){
        return component[INDEX_CACHE] = getAbsoluteIndex(previousSibling) + 1;
    }

    return component[INDEX_CACHE] = getAbsoluteIndex(parent) + relativeIndex;
}

module.exports = function insertIntoParent(component, parentComponent, index){
    if(!parentComponent){
        return;
    }

    var containerElement = parentComponent.containerElement || parentComponent.element;

    if(!containerElement){
        return;
    }
    
    // if(!component.element){
    //     var componentConfig = getComponentConfig(component);
    //     component.render(componentConfig.renderers);
    // }

    var absoluteIndex = getAbsoluteIndex(component);

    if(Array.isArray(containerElement) || containerElement.childNodes[absoluteIndex] === component.element){
        return;
    }

    containerElement.insertBefore(component.element, containerElement.childNodes[absoluteIndex]);
}

},{"fastn":16,"fastn/getComponentConfig":15}],3:[function(require,module,exports){
module.exports = function(element){
    var lastClasses = [];

    return function(classes){

        if(!arguments.length){
            return lastClasses.join(' ');
        }

        function cleanClassName(result, className){
            if(typeof className === 'string' && className.match(/\s/)){
                className = className.split(' ');
            }

            if(Array.isArray(className)){
                return result.concat(className.reduce(cleanClassName, []));
            }

            if(className != null && className !== '' && typeof className !== 'boolean'){
                result.push(String(className).trim());
            }

            return result;
        }

        var newClasses = cleanClassName([], classes),
            currentClasses = element.className ? element.className.split(' ') : [];

        lastClasses.map(function(className){
            if(!className){
                return;
            }

            var index = currentClasses.indexOf(className);

            if(~index){
                currentClasses.splice(index, 1);
            }
        });

        if(lastClasses.join() === newClasses.join()){
            return;
        }

        currentClasses = currentClasses.concat(newClasses);
        lastClasses = newClasses;

        element.className = currentClasses.join(' ');
    };
};

},{}],4:[function(require,module,exports){
var setify = require('setify');
var classist = require('classist');
var CLASSIST = Symbol('classist');

function updateTextProperty(element, value){
    if(arguments.length === 1){
        return element.textContent;
    }
    element.textContent = (value == null ? '' : value);
}

module.exports = {
    class: function(element, value){
        if(!element[CLASSIST]){
            element[CLASSIST] = classist(element);
        }

        if(arguments.length === 1){
            return element[CLASSIST]();
        }

        element[CLASSIST](value);
    },
    display: function(element, value){
        if(arguments.length === 1){
            return element.style.display !== 'none';
        }
        element.style.display = value ? '' : 'none';
    },
    disabled: function(element, value){
        if(arguments.length === 1){
            return element.hasAttribute('disabled');
        }
        if(value){
            element.setAttribute('disabled', 'disabled');
        }else{
            element.removeAttribute('disabled');
        }
    },
    textContent: updateTextProperty,
    innerText: updateTextProperty,
    innerHTML: function(element, value){
        if(arguments.length === 1){
            return element.innerHTML;
        }
        element.innerHTML = (value == null ? '' : value);
    },
    value: function(element, value){
        var inputType = element.type;

        if(element.nodeName === 'INPUT' && inputType === 'date'){
            if(arguments.length === 1){
                return element.value ? new Date(element.value.replace(/-/g,'/').replace('T',' ')) : null;
            }

            value = value != null ? new Date(value) : null;

            if(!value || isNaN(value)){
                element.value = null;
            }else{
                element.value = [
                    value.getFullYear(),
                    ('0' + (value.getMonth() + 1)).slice(-2),
                    ('0' + value.getDate()).slice(-2)
                ].join('-');
            }
            return;
        }

        if(arguments.length === 1){
            if(element.nodeName === 'PROGRESS'){
                return (!element.value || isNaN(element.value)) ? 0 : parseFloat(element.value);
            }
            return element.value;
        }

        if(value === undefined){
            value = null;
        }

        if(element.nodeName === 'PROGRESS'){
            value = parseFloat(value) || 0;
        }

        setify(element, value);
    },
    max: function(element, value) {
        if(arguments.length === 1){
            return isNaN(element.max) ? null : parseFloat(element.max);
        }

        if(element.nodeName === 'PROGRESS'){
            value = parseFloat(value) || 0;
        }

        element.max = (value == null || isNaN(value)) ? '' : String(value);
    },
    style: function(element, value){
        if(arguments.length === 1){
            return element.style;
        }

        if(typeof value === 'string'){
            element.style = value;
        }

        for(var key in value){
            element.style[key] = value[key];
        }
    },
    type: function(element, value){
        if(arguments.length === 1){
            return element.type || null;
        }
        element.setAttribute('type', value == null ? '' : value);
    }
};
},{"classist":3,"setify":6}],5:[function(require,module,exports){
var supportedTypes = ['textarea', 'text', 'search', 'tel', 'url', 'password'];

module.exports = function(element) {
    return !!(element.setSelectionRange && ~supportedTypes.indexOf(element.type));
};

},{}],6:[function(require,module,exports){
var naturalSelection = require('natural-selection');

module.exports = function(element, value){
    var canSet = naturalSelection(element) && element === document.activeElement;

    if (canSet) {
        var start = element.selectionStart,
            end = element.selectionEnd;

        element.value = value;
        element.setSelectionRange(start, end);
    } else {
        element.value = value;
    }
};

},{"natural-selection":5}],7:[function(require,module,exports){
function registerRenderer(renderers, key, renderer){
    renderers = renderers || {};
    renderers[key] = renderers[key] || renderer;
    return renderers;
}

module.exports = registerRenderer;
},{}],8:[function(require,module,exports){
var fastn = require('fastn');
var registerRenderer = require('./registerRenderer');
var insertIntoParent = require('./insertIntoParent');
var getComponentConfig = require('fastn/getComponentConfig');

function updateText(component, text){
    if(!component.element){
        return;
    }

    component.element.data = (text == null ? '' : text);
}

function renderTextComponent(component){
    component.element = document.createTextNode(component.text);
    updateText(component, component.text);
    component.on('text', value => updateText(component, value));
    component.on('insertElement', (parentComponent, index) => insertIntoParent(component, parentComponent, index))
    component.on('removeElement', (parentComponent, index) => component.element && component.element.remove())
}

function textComponent(settings){
    if(typeof settings === 'string' || typeof settings === 'number' || fastn.is.attachable(settings)){
        settings = { text: settings };
    }

    var component = fastn.component(settings);

    fastn.setProperty(component, 'text', {
        value: component.text || ''
    });
    

    component.render = function(renderers){
        if(component.element){
            return;
        }
        renderers = registerRenderer(renderers, 'text', renderTextComponent);
        renderers.text(component);
        component.emit('render', component, renderers);
    }

    return component;
}

module.exports = textComponent;
},{"./insertIntoParent":2,"./registerRenderer":7,"fastn":16,"fastn/getComponentConfig":15}],9:[function(require,module,exports){
var dom = require('fastn-dom')
var text = require('fastn-dom/text')
var list = require('../')
var binding = require('fastn/binding')
var mutate = require('fastn/mutate')

var state = {
    things: []
};

mutate.set(state, 'things', Array.from(new Array(3000)).map((item, index) => String.fromCharCode(index + 97)));

var ui = dom('div', { class: 'Totes parent' },

    dom('table',
        dom('thead',
            dom('th', 
                dom('td', 'Some column header')
            )
        ),
        dom('tbody',
            list({
                items: binding('things'),
                template: () =>
                    list(
                        dom('tr', 
                            dom('td', 'Index: ', binding('key'))
                        ),
                        dom('tr', 
                            dom('td', 'Foo: ', binding('item'))
                        )
                    )
            })
        )
    ),

    list(text('a'), 'b'),

    dom('h1', 'fastn-dom demo app'),
    dom('section',
        dom('p',
            'Name: ', dom('label', binding('name'))
        ),
        dom('form',
            dom('input', {
                placeholder: 'Enter name',
                value: binding('name')
            })
            .on('input', (event, componentState, component) => {
                mutate.set(state, 'name', event.target.value);
            }),
            dom('button', { type: 'button' }, 'X')
            .on('click', (event, componentState, component) => {
                mutate.remove(state, 'name');
            })
        )
        .on('submit', (event, componentState, component) => {
            event.preventDefault();
            mutate.push(state, 'things', componentState.name);
            mutate.remove(state, 'name');
        }),
        dom('table',
            list({
                items: binding('things|*'),
                template: (itemState, componentState) => {
                    return list(
                        binding('key', key => `key: ${key}`),
                        list(
                            dom('span', 'x'),
                            dom('span', 'y')
                        ),
                        dom('tr', 
                            dom('td', 'Foo')
                        ),
                        dom('tr',
                            dom('div',
                                binding('item', item => `item: ${item}`)
                                ),
                            dom('button', { type: 'button' }, 'X')
                            .on('click', (event, componentState, component) => {
                                mutate.remove(state.things, itemState.key);
                            })
                        ) 
                    )
                }
            })
        )
    )
)
.attach(state)
.render()

setTimeout(function(){
    mutate.set(state, 'things.1', 'THINGO');
}, 1000)

window.addEventListener('DOMContentLoaded', () => document.body.appendChild(ui.element))
},{"../":10,"fastn-dom":1,"fastn-dom/text":8,"fastn/binding":13,"fastn/mutate":18}],10:[function(require,module,exports){
var fastn = require('fastn');
var mutate = require('fastn/mutate');
var getComponentConfig = require('fastn/getComponentConfig');
var componentTemplateMap = new WeakMap();
var componentDataMap = new WeakMap();

function each(value, fn){
    if(!value || typeof value !== 'object'){
        return;
    }

    if(Array.isArray(value)){
        for(var i = 0; i < value.length; i++){
            fn(value[i], i)
        }
    }else{
        for(var key in value){
            fn(value[key], key);
        }
    }
}

function keyFor(object, value, taken){
    if(!object || typeof object !== 'object'){
        return false;
    }

    if(Array.isArray(object)){
        for(var i = 0; i < object.length; i++){
            if(object[i] === value && !(i in taken)){
                return i;
            }
        }
    }

    for(var key in object){
        if(object[key] === value && !(key in taken)){
            return key;
        }
    }

    return false;
}

function updateItems(component, items){
    var componentConfig = getComponentConfig(component);

    insertQueue = [];

    var value = component.items;
    var template = component.template;
    var emptyTemplate = component.emptyTemplate;
    var insertionFrameTime = component.insertionFrameTime || Infinity;

    var updates = value ? Array.isArray(value) ? [] : {} : [];

    fastn.component.getChildren(component).slice().forEach(function(childComponent, index){
        var itemData = componentDataMap.get(childComponent);
        var componentTemplate = componentTemplateMap.get(childComponent);

        if(!componentTemplate){
            // Not a templated component
            return;
        }
        
        var currentKey = keyFor(value, itemData.item, updates);

        if(componentTemplate === template && currentKey !== false){
            updates[currentKey] = [itemData, null, childComponent];
        } else {
            componentTemplateMap.delete(childComponent);
            fastn.component.remove(childComponent);
            childComponent.emit('removeElement');
            componentDataMap.delete(childComponent)
        }
    });

    var currentIndex = 0;
    each(value, (item, key) => {
        if(updates[key]){
            updates[key][1] = currentIndex++
            return
        }

        var itemData = { item, key };

        updates[key] = [itemData, currentIndex++];
    });

    each(updates, function(update, key){
        var itemData = update[0];
        var childIndex = update[1];
        var childComponent = update[2];

        mutate.set(itemData, 'key', key);

        if(!childComponent){
            childComponent = template(itemData, componentConfig.state).attach(itemData, 2);
            componentTemplateMap.set(childComponent, template);
        }

        componentDataMap.set(childComponent, itemData);

        if(componentConfig.renderers){
            childComponent.render(componentConfig.renderers);
        }
        fastn.component.insertChild(component, childComponent, childIndex);
        childComponent.emit('insertElement', component, childIndex);
    });
}

function renderListComponent(component){
    component.element = [];

    var parentComponent = fastn.component.getParent(component);

    if(parentComponent){
        component.containerElement = parentComponent.containerElement || parentComponent.element;
    }

    component.on('insertElement', (parentComponent, index) => {
        var componentConfig = getComponentConfig(component);

        if(component.element){
            component.containerElement = parentComponent.containerElement || parentComponent.element;
        }

        fastn.component.getChildren(component).forEach((child, childIndex) => {
            child.emit('insertElement', component, childIndex);
        });
    });
    component.on('removeElement', () => 
        fastn.component.getChildren(component).forEach(child => child.emit('removeElement'))
    );

    return component;
}

function listComponent(settings, ...children){
    if(typeof settings === 'string' || typeof settings === 'number' || fastn.is.attachable(settings)){
        children.unshift(settings);
        settings = {};
    }

    var component = fastn.component(settings, children);

    fastn.setProperty(component, 'items', {
        value: component.items || []
    });

    var hasRendered;
    component.render = function(renderers){

        if(component.element){
            return;
        }
        var componentConfig = getComponentConfig(component);
        renderers['list'] = renderers['list'] || renderListComponent;
        renderers.list(component);
        componentConfig.renderers = renderers;

        component.emit('render', component, renderers);

        var parentComponent = fastn.component.getParent(component);

        if(parentComponent){
            component.containerElement = parentComponent.containerElement || parentComponent.element;
        }

        fastn.component.getChildren(component).forEach((child, childIndex) => {
            child.render(componentConfig.renderers);
            if(parentComponent){
                child.emit('insertElement', component, childIndex);
            }
        });

        return component;
    }

    updateItems(component, component.items);
    component.on('items', items => updateItems(component, items));

    return component;
}

module.exports = listComponent;
},{"fastn":16,"fastn/getComponentConfig":15,"fastn/mutate":18}],11:[function(require,module,exports){
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

var objectCreate = Object.create || objectCreatePolyfill
var objectKeys = Object.keys || objectKeysPolyfill
var bind = Function.prototype.bind || functionBindPolyfill

function EventEmitter() {
  if (!this._events || !Object.prototype.hasOwnProperty.call(this, '_events')) {
    this._events = objectCreate(null);
    this._eventsCount = 0;
  }

  this._maxListeners = this._maxListeners || undefined;
}
module.exports = EventEmitter;

// Backwards-compat with node 0.10.x
EventEmitter.EventEmitter = EventEmitter;

EventEmitter.prototype._events = undefined;
EventEmitter.prototype._maxListeners = undefined;

// By default EventEmitters will print a warning if more than 10 listeners are
// added to it. This is a useful default which helps finding memory leaks.
var defaultMaxListeners = 10;

var hasDefineProperty;
try {
  var o = {};
  if (Object.defineProperty) Object.defineProperty(o, 'x', { value: 0 });
  hasDefineProperty = o.x === 0;
} catch (err) { hasDefineProperty = false }
if (hasDefineProperty) {
  Object.defineProperty(EventEmitter, 'defaultMaxListeners', {
    enumerable: true,
    get: function() {
      return defaultMaxListeners;
    },
    set: function(arg) {
      // check whether the input is a positive number (whose value is zero or
      // greater and not a NaN).
      if (typeof arg !== 'number' || arg < 0 || arg !== arg)
        throw new TypeError('"defaultMaxListeners" must be a positive number');
      defaultMaxListeners = arg;
    }
  });
} else {
  EventEmitter.defaultMaxListeners = defaultMaxListeners;
}

// Obviously not all Emitters should be limited to 10. This function allows
// that to be increased. Set to zero for unlimited.
EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
  if (typeof n !== 'number' || n < 0 || isNaN(n))
    throw new TypeError('"n" argument must be a positive number');
  this._maxListeners = n;
  return this;
};

function $getMaxListeners(that) {
  if (that._maxListeners === undefined)
    return EventEmitter.defaultMaxListeners;
  return that._maxListeners;
}

EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
  return $getMaxListeners(this);
};

// These standalone emit* functions are used to optimize calling of event
// handlers for fast cases because emit() itself often has a variable number of
// arguments and can be deoptimized because of that. These functions always have
// the same number of arguments and thus do not get deoptimized, so the code
// inside them can execute faster.
function emitNone(handler, isFn, self) {
  if (isFn)
    handler.call(self);
  else {
    var len = handler.length;
    var listeners = arrayClone(handler, len);
    for (var i = 0; i < len; ++i)
      listeners[i].call(self);
  }
}
function emitOne(handler, isFn, self, arg1) {
  if (isFn)
    handler.call(self, arg1);
  else {
    var len = handler.length;
    var listeners = arrayClone(handler, len);
    for (var i = 0; i < len; ++i)
      listeners[i].call(self, arg1);
  }
}
function emitTwo(handler, isFn, self, arg1, arg2) {
  if (isFn)
    handler.call(self, arg1, arg2);
  else {
    var len = handler.length;
    var listeners = arrayClone(handler, len);
    for (var i = 0; i < len; ++i)
      listeners[i].call(self, arg1, arg2);
  }
}
function emitThree(handler, isFn, self, arg1, arg2, arg3) {
  if (isFn)
    handler.call(self, arg1, arg2, arg3);
  else {
    var len = handler.length;
    var listeners = arrayClone(handler, len);
    for (var i = 0; i < len; ++i)
      listeners[i].call(self, arg1, arg2, arg3);
  }
}

function emitMany(handler, isFn, self, args) {
  if (isFn)
    handler.apply(self, args);
  else {
    var len = handler.length;
    var listeners = arrayClone(handler, len);
    for (var i = 0; i < len; ++i)
      listeners[i].apply(self, args);
  }
}

EventEmitter.prototype.emit = function emit(type) {
  var er, handler, len, args, i, events;
  var doError = (type === 'error');

  events = this._events;
  if (events)
    doError = (doError && events.error == null);
  else if (!doError)
    return false;

  // If there is no 'error' event listener then throw.
  if (doError) {
    if (arguments.length > 1)
      er = arguments[1];
    if (er instanceof Error) {
      throw er; // Unhandled 'error' event
    } else {
      // At least give some kind of context to the user
      var err = new Error('Unhandled "error" event. (' + er + ')');
      err.context = er;
      throw err;
    }
    return false;
  }

  handler = events[type];

  if (!handler)
    return false;

  var isFn = typeof handler === 'function';
  len = arguments.length;
  switch (len) {
      // fast cases
    case 1:
      emitNone(handler, isFn, this);
      break;
    case 2:
      emitOne(handler, isFn, this, arguments[1]);
      break;
    case 3:
      emitTwo(handler, isFn, this, arguments[1], arguments[2]);
      break;
    case 4:
      emitThree(handler, isFn, this, arguments[1], arguments[2], arguments[3]);
      break;
      // slower
    default:
      args = new Array(len - 1);
      for (i = 1; i < len; i++)
        args[i - 1] = arguments[i];
      emitMany(handler, isFn, this, args);
  }

  return true;
};

function _addListener(target, type, listener, prepend) {
  var m;
  var events;
  var existing;

  if (typeof listener !== 'function')
    throw new TypeError('"listener" argument must be a function');

  events = target._events;
  if (!events) {
    events = target._events = objectCreate(null);
    target._eventsCount = 0;
  } else {
    // To avoid recursion in the case that type === "newListener"! Before
    // adding it to the listeners, first emit "newListener".
    if (events.newListener) {
      target.emit('newListener', type,
          listener.listener ? listener.listener : listener);

      // Re-assign `events` because a newListener handler could have caused the
      // this._events to be assigned to a new object
      events = target._events;
    }
    existing = events[type];
  }

  if (!existing) {
    // Optimize the case of one listener. Don't need the extra array object.
    existing = events[type] = listener;
    ++target._eventsCount;
  } else {
    if (typeof existing === 'function') {
      // Adding the second element, need to change to array.
      existing = events[type] =
          prepend ? [listener, existing] : [existing, listener];
    } else {
      // If we've already got an array, just append.
      if (prepend) {
        existing.unshift(listener);
      } else {
        existing.push(listener);
      }
    }

    // Check for listener leak
    if (!existing.warned) {
      m = $getMaxListeners(target);
      if (m && m > 0 && existing.length > m) {
        existing.warned = true;
        var w = new Error('Possible EventEmitter memory leak detected. ' +
            existing.length + ' "' + String(type) + '" listeners ' +
            'added. Use emitter.setMaxListeners() to ' +
            'increase limit.');
        w.name = 'MaxListenersExceededWarning';
        w.emitter = target;
        w.type = type;
        w.count = existing.length;
        if (typeof console === 'object' && console.warn) {
          console.warn('%s: %s', w.name, w.message);
        }
      }
    }
  }

  return target;
}

EventEmitter.prototype.addListener = function addListener(type, listener) {
  return _addListener(this, type, listener, false);
};

EventEmitter.prototype.on = EventEmitter.prototype.addListener;

EventEmitter.prototype.prependListener =
    function prependListener(type, listener) {
      return _addListener(this, type, listener, true);
    };

function onceWrapper() {
  if (!this.fired) {
    this.target.removeListener(this.type, this.wrapFn);
    this.fired = true;
    switch (arguments.length) {
      case 0:
        return this.listener.call(this.target);
      case 1:
        return this.listener.call(this.target, arguments[0]);
      case 2:
        return this.listener.call(this.target, arguments[0], arguments[1]);
      case 3:
        return this.listener.call(this.target, arguments[0], arguments[1],
            arguments[2]);
      default:
        var args = new Array(arguments.length);
        for (var i = 0; i < args.length; ++i)
          args[i] = arguments[i];
        this.listener.apply(this.target, args);
    }
  }
}

function _onceWrap(target, type, listener) {
  var state = { fired: false, wrapFn: undefined, target: target, type: type, listener: listener };
  var wrapped = bind.call(onceWrapper, state);
  wrapped.listener = listener;
  state.wrapFn = wrapped;
  return wrapped;
}

EventEmitter.prototype.once = function once(type, listener) {
  if (typeof listener !== 'function')
    throw new TypeError('"listener" argument must be a function');
  this.on(type, _onceWrap(this, type, listener));
  return this;
};

EventEmitter.prototype.prependOnceListener =
    function prependOnceListener(type, listener) {
      if (typeof listener !== 'function')
        throw new TypeError('"listener" argument must be a function');
      this.prependListener(type, _onceWrap(this, type, listener));
      return this;
    };

// Emits a 'removeListener' event if and only if the listener was removed.
EventEmitter.prototype.removeListener =
    function removeListener(type, listener) {
      var list, events, position, i, originalListener;

      if (typeof listener !== 'function')
        throw new TypeError('"listener" argument must be a function');

      events = this._events;
      if (!events)
        return this;

      list = events[type];
      if (!list)
        return this;

      if (list === listener || list.listener === listener) {
        if (--this._eventsCount === 0)
          this._events = objectCreate(null);
        else {
          delete events[type];
          if (events.removeListener)
            this.emit('removeListener', type, list.listener || listener);
        }
      } else if (typeof list !== 'function') {
        position = -1;

        for (i = list.length - 1; i >= 0; i--) {
          if (list[i] === listener || list[i].listener === listener) {
            originalListener = list[i].listener;
            position = i;
            break;
          }
        }

        if (position < 0)
          return this;

        if (position === 0)
          list.shift();
        else
          spliceOne(list, position);

        if (list.length === 1)
          events[type] = list[0];

        if (events.removeListener)
          this.emit('removeListener', type, originalListener || listener);
      }

      return this;
    };

EventEmitter.prototype.removeAllListeners =
    function removeAllListeners(type) {
      var listeners, events, i;

      events = this._events;
      if (!events)
        return this;

      // not listening for removeListener, no need to emit
      if (!events.removeListener) {
        if (arguments.length === 0) {
          this._events = objectCreate(null);
          this._eventsCount = 0;
        } else if (events[type]) {
          if (--this._eventsCount === 0)
            this._events = objectCreate(null);
          else
            delete events[type];
        }
        return this;
      }

      // emit removeListener for all listeners on all events
      if (arguments.length === 0) {
        var keys = objectKeys(events);
        var key;
        for (i = 0; i < keys.length; ++i) {
          key = keys[i];
          if (key === 'removeListener') continue;
          this.removeAllListeners(key);
        }
        this.removeAllListeners('removeListener');
        this._events = objectCreate(null);
        this._eventsCount = 0;
        return this;
      }

      listeners = events[type];

      if (typeof listeners === 'function') {
        this.removeListener(type, listeners);
      } else if (listeners) {
        // LIFO order
        for (i = listeners.length - 1; i >= 0; i--) {
          this.removeListener(type, listeners[i]);
        }
      }

      return this;
    };

function _listeners(target, type, unwrap) {
  var events = target._events;

  if (!events)
    return [];

  var evlistener = events[type];
  if (!evlistener)
    return [];

  if (typeof evlistener === 'function')
    return unwrap ? [evlistener.listener || evlistener] : [evlistener];

  return unwrap ? unwrapListeners(evlistener) : arrayClone(evlistener, evlistener.length);
}

EventEmitter.prototype.listeners = function listeners(type) {
  return _listeners(this, type, true);
};

EventEmitter.prototype.rawListeners = function rawListeners(type) {
  return _listeners(this, type, false);
};

EventEmitter.listenerCount = function(emitter, type) {
  if (typeof emitter.listenerCount === 'function') {
    return emitter.listenerCount(type);
  } else {
    return listenerCount.call(emitter, type);
  }
};

EventEmitter.prototype.listenerCount = listenerCount;
function listenerCount(type) {
  var events = this._events;

  if (events) {
    var evlistener = events[type];

    if (typeof evlistener === 'function') {
      return 1;
    } else if (evlistener) {
      return evlistener.length;
    }
  }

  return 0;
}

EventEmitter.prototype.eventNames = function eventNames() {
  return this._eventsCount > 0 ? Reflect.ownKeys(this._events) : [];
};

// About 1.5x faster than the two-arg version of Array#splice().
function spliceOne(list, index) {
  for (var i = index, k = i + 1, n = list.length; k < n; i += 1, k += 1)
    list[i] = list[k];
  list.pop();
}

function arrayClone(arr, n) {
  var copy = new Array(n);
  for (var i = 0; i < n; ++i)
    copy[i] = arr[i];
  return copy;
}

function unwrapListeners(arr) {
  var ret = new Array(arr.length);
  for (var i = 0; i < ret.length; ++i) {
    ret[i] = arr[i].listener || arr[i];
  }
  return ret;
}

function objectCreatePolyfill(proto) {
  var F = function() {};
  F.prototype = proto;
  return new F;
}
function objectKeysPolyfill(obj) {
  var keys = [];
  for (var k in obj) if (Object.prototype.hasOwnProperty.call(obj, k)) {
    keys.push(k);
  }
  return k;
}
function functionBindPolyfill(context) {
  var fn = this;
  return function () {
    return fn.apply(context, arguments);
  };
}

},{}],12:[function(require,module,exports){
function firmer(newFirmness, firmness){
    if(firmness != null && (newFirmness === undefined || firmness < newFirmness)){
        return true;
    }
}

module.exports = function(emitter){
    var firmness = -1;

    function attach(data, newFirmness){
        if(!data || typeof data !== 'object'){
            throw new Error('non-object passed to fastnComponent.attach()');
        }

        if(!firmer(newFirmness, firmness)){
            return emitter;
        }

        firmness = newFirmness;

        emitter.emit('attach', data, firmness);

        return emitter;
    }

    function detach(soft){
        emitter.emit('detach', soft);
    }

    emitter.attach = attach;
    emitter.detach = detach;
}
},{}],13:[function(require,module,exports){
var functionEmitter = require('function-emitter');
var attachable = require('./attachable');
var Enti = require('enti');
var is = require('./is');

module.exports = function(...args){
    var argValues = [];
    var currentValue;
    var model = new Enti();
    var transform = args.length > 1 && args.pop();
    var emitQueued;
    var handlersAttached;

    var binding = function(){
        return currentValue;
    };

    Object.setPrototypeOf(binding, functionEmitter);
    attachable(binding);

    function updateArgValue(arg, argIndex){
        if(typeof arg === 'function'){
            argValues[argIndex] = arg();
        } else if(typeof arg === 'string' || typeof arg === 'number') {
            argValues[argIndex] = model.get(arg);
        }
    }

    function updateCurrentValue(){
        args.map(updateArgValue);
        currentValue = transform ? transform.apply(null, argValues) : argValues[0];
    }

    function runAndEmitChange(fn){
        var emit;

        if(!emitQueued){
            emitQueued = emit = true;
        }

        fn();

        if(emit){
            emitQueued = false;
            binding.emit('change', currentValue);
        }
    }

    var handlers = args.map((arg, argIndex) => {
        var handler = function(value){
            runAndEmitChange(() => {
                argValues[argIndex] = value;
                updateCurrentValue();
            });
        }

        if(!is.emitter(arg) && typeof arg !== 'string' && typeof arg !== 'number'){
            throw new Error(`Unexpected value passed to binding(), argument ${argIndex} was not a string, number, or observable.`);
        }

        updateArgValue(arg, argIndex);
        
        return handler;
    });

    function attachHandlers(){
        if(handlersAttached){
            return;
        }

        args.forEach((arg, argIndex) => {
            if(typeof arg === 'string' || typeof arg === 'number'){
                model.on(arg, handlers[argIndex]);
            } else if(is.emitter(arg)) {
                arg.on('change', handlers[argIndex]);
            }
        });

        handlersAttached = true;
    }

    function attach(state){
        runAndEmitChange(() => {
            attachHandlers();
            model.attach(state);
            updateCurrentValue();
        });
    }

    function detach(soft){
        if(soft && binding._handlers && binding._handlers.change && binding._handlers.change.length > 0){
            return
        }

        runAndEmitChange(() => {
            model.detach();

            args.forEach(function(arg, argIndex){
                if(is.emitter(arg)){
                    arg.removeListener('change', handlers[argIndex])
                }
                if(is.attachable(arg)){
                    arg.detach(true);
                }
                handlersAttached = false;
            });

            argValues = [];
            currentValue = undefined;
        });
    }

    binding.on('attach', attach);
    binding.on('detach', detach);

    attachHandlers();
    updateCurrentValue();

    return binding;
}
},{"./attachable":12,"./is":17,"enti":19,"function-emitter":20}],14:[function(require,module,exports){
var EventEmitter = require('events');
var attachable = require('./attachable');
var getComponentConfig = require('./getComponentConfig');
var setProperty = require('./setProperty');
var is = require('./is');
var PARENT = Symbol.for('parent');

function getChildren(component){
    return getComponentConfig(component).children;
}

function remove(component){
    var parent = component && component[PARENT];

    if(parent){
        removeChild(parent, component);
        parent.emit('childRemove', component);
    }
}

function empty(component){
    var children = getComponentConfig(component).children;
    children.forEach(child => remove(child));
}

function removeChild(component, child){
    var children = getComponentConfig(component).children;
    var index = children.indexOf(child);

    if(~index){
        children.splice(index, 1);
    }

    child[PARENT] = null;
}

function insertChild(component, child, index){
    var componentConfig = getComponentConfig(component);
    var state = componentConfig.state;
    var children = componentConfig.children;

    index = index || 0;

    if(Array.isArray(child)){
        var newChildren = child.flat();
        newChildren.forEach((subChild, subIndex) => {
            insertChild(component, subChild, index + subIndex);
        });
        return component;
    }

    if(child === null || child === false){
        return component;
    }

    if(!is.component(child)){
        child = createComponent({ text: child });
        child.render = function(renderers){
            renderers.text(child);
            child.emit('render', child, renderers);
        }
    }

    if(child[PARENT] === component && children[index] === child){
        return component;
    }

    remove(child);

    child[PARENT] = component;
    children.splice(index, 0, child);

    if(state){
        child.attach(state, 1);
    }

    component.emit('childInsert', child, index);

    return component;
}

function getParent(component){
    return component[PARENT];
}

function getOwnIndex(component){
    if(!isis.component(component)){
        throw new Error(`non-componant passed to getOwnIndex: ${typeof component}: ${component}`)
    }

    var parent = getParent(component);

    if(!parent){
        return -1;
    }

    return getChildren(parent).indexOf(component);
}

function createComponent(settings, ...children){
    var component = new EventEmitter();

    var componentConfig = getComponentConfig(component);

    if(settings && is.attachable(settings)){
        children.unshift(settings);
        settings = null;
    }

    componentConfig.children = [];

    insertChild(component, children);

    component.on('attach', (data, firmness) => {
        componentConfig.state = data;
        componentConfig.children.forEach(child => is.attachable(child) && child.attach(data, 1))
    });
    component.on('detach', (soft) => componentConfig.children.forEach(child => is.attachable(child) && child.detach(true)));

    attachable(component);

    if (settings) {
        Object.keys(settings).forEach(key => {
            if(is.emitter(settings[key])){
                setProperty(component, key, {
                    emitter: settings[key]
                })
            } else {
                setProperty(component, key, {
                    value: settings[key]
                })
            }
        });
    }

    return component;
}

module.exports = createComponent
createComponent.insertChild = insertChild;
createComponent.getChildren = getChildren;
createComponent.getOwnIndex = getOwnIndex;
createComponent.remove = remove;
createComponent.empty = empty;
createComponent.getParent = getParent;
},{"./attachable":12,"./getComponentConfig":15,"./is":17,"./setProperty":22,"events":11}],15:[function(require,module,exports){
var COMPONENT_CONFIG = Symbol.for('configuration');

module.exports = function getComponentConfig(component){
    var componentConfig = component[COMPONENT_CONFIG];

    if(!componentConfig){
        componentConfig = {};
        component[COMPONENT_CONFIG] = componentConfig;
    }

    if(!componentConfig.properties){
        componentConfig.properties = {};
    }

    if(!componentConfig.children){
        componentConfig.children = [];
    }

    return componentConfig;
}
},{}],16:[function(require,module,exports){
var getComponentConfig = require('./getComponentConfig');
var component = require('./component');
var is = require('./is');
var setProperty = require('./setProperty');

module.exports = {
    component,
    setProperty,
    is
}
},{"./component":14,"./getComponentConfig":15,"./is":17,"./setProperty":22}],17:[function(require,module,exports){
var COMPONENT_CONFIG = Symbol.for('configuration');

function isEmitter(value){
    return value && typeof value.on === 'function' && typeof value.removeListener === 'function';
}

function isAttachable(value){
    return value && typeof value.attach === 'function';
}

function isComponent(value){
    return value && isAttachable(value) && value[COMPONENT_CONFIG]
}

module.exports = {
    emitter: isEmitter,
    attachable: isAttachable,
    component: isComponent
};
},{}],18:[function(require,module,exports){
module.exports = require('enti');

},{"enti":19}],19:[function(require,module,exports){
(function (global){
var EventEmitter = require('events').EventEmitter,
    isInstance = require('is-instance');

function createPool(growSize, create, dispose){
    var pool = [];
    var index = -1;
    var totalCreated = 0;
    var totalDisposed = 0;

    return {
        size: function(){
            return pool.length;
        },
        created: function(){
            return totalCreated;
        },
        disposed: function(){
            return totalDisposed;
        },
        get: function(){
            if(index >= 0){
                var item = pool[index];
                pool[index] = null;
                index--;
                return item;
            }

            totalCreated++;
            return create();
        },
        dispose: function(object){
            totalDisposed++;
            dispose(object);
            if(index >= pool.length){
                pool = pool.concat(new Array(growSize));
            }
            index++;
            pool[index] = object;
        }
    }
}

var setPool = createPool(1000, function(){
    return new Set();
}, function(set){
    set.clear();
});

var emitKeyPool = createPool(10, function(){
    return new Map();
}, function(emitKey){
    emitKey.forEach(setPool.dispose);
    emitKey.clear();
});

function toArray(items){
    return Array.prototype.slice.call(items);
}

var deepRegex = /[|.]/i;

function matchDeep(path){
    return (path + '').match(deepRegex);
}

function isWildcardPath(path){
    var stringPath = (path + '');
    return ~stringPath.indexOf('*');
}

function getTargetKey(path){
    var stringPath = (path + '');
    return stringPath.split('|').shift();
}

var eventSystemVersion = 1,
    globalKey = '_entiEventState' + eventSystemVersion,
    globalState = global[globalKey] = global[globalKey] || {
        instances: [],
        getPoolInfo: function(){
            return [
                'setPool', setPool.size(),
                'created', setPool.created(),
                'disposed', setPool.disposed(),
                'emitKeyPool', emitKeyPool.size(),
                'created', emitKeyPool.created(),
                'disposed', emitKeyPool.disposed()
            ];
        }
    };

var modifiedEnties = globalState.modifiedEnties_v6 = globalState.modifiedEnties_v6 || setPool.get();
var trackedObjects = globalState.trackedObjects_v6 = globalState.trackedObjects_v6 || new WeakMap();
var trackedHandlers = globalState.trackedHandlers_v6 = globalState.trackedHandlers_v6 || new WeakMap();

function leftAndRest(path){
    var stringPath = (path + '');

    // Special case when you want to filter on self (.)
    if(stringPath.slice(0,2) === '.|'){
        return ['.', stringPath.slice(2)];
    }

    var match = matchDeep(stringPath);
    if(match){
        return [stringPath.slice(0, match.index), stringPath.slice(match.index+1)];
    }
    return stringPath;
}

function isWildcardKey(key){
    return key.charAt(0) === '*';
}

function isFeralcardKey(key){
    return key === '**';
}

function addHandler(object, key, handler, parentHandler){
    var trackedKeys = trackedObjects.get(object);
    var trackedHandler = trackedHandlers.get(parentHandler);

    if(trackedKeys == null){
        trackedKeys = {};
        trackedObjects.set(object, trackedKeys);
    }
    if(trackedHandler == null){
        trackedHandler = new WeakMap();
        trackedHandlers.set(parentHandler, new WeakMap());
    }

    if(trackedHandler.get(object) == null){
        trackedHandler.set(object, setPool.get());
    }

    if(trackedHandler.get(object).has(key)){
        return;
    }

    var handlers = trackedKeys[key];

    if(!handlers){
        handlers = setPool.get();
        trackedKeys[key] = handlers;
    }

    handlers.add(handler);
    trackedHandler.get(object).add(key);
}

function removeHandler(object, key, handler, parentHandler){
    var trackedKeys = trackedObjects.get(object);
    var trackedHandler = trackedHandlers.get(parentHandler);

    if(
        trackedKeys == null ||
        trackedHandler == null ||
        trackedHandler.get(object) == null ||
        !trackedHandler.get(object).has(key)
    ){
        return;
    }

    var handlers = trackedKeys[key];

    if(!handlers){
        return;
    }

    handlers.delete(handler);
    if(handlers.size === 0){
        setPool.dispose(handlers);
        delete trackedKeys[key];
    }
    var trackedObjectHandlerSet = trackedHandler.get(object);
    trackedObjectHandlerSet.delete(key);
    if(trackedObjectHandlerSet.size === 0){
        setPool.dispose(trackedObjectHandlerSet);
        trackedHandler.delete(object);
    }
}

function trackObjects(eventName, tracked, handler, object, key, path){
    if(!object || typeof object !== 'object'){
        return;
    }

    var target = object[key];

    if(target && typeof target === 'object' && tracked.has(target)){
        return;
    }

    trackObject(eventName, tracked, handler, object, key, path);
}

function trackKeys(eventName, tracked, handler, target, root, rest){
    var keys = Object.keys(target);
    for(var i = 0; i < keys.length; i++){
        if(isFeralcardKey(root)){
            trackObjects(eventName, tracked, handler, target, keys[i], '**' + (rest ? '.' : '') + (rest || ''));
        }else{
            trackObjects(eventName, tracked, handler, target, keys[i], rest);
        }
    }
}

function trackObject(eventName, tracked, handler, object, key, path){
    var eventKey = key === '**' ? '*' : key,
        target = object[key],
        targetIsObject = target && typeof target === 'object';

    var handle = function(event, emitKey){
        if(eventKey !== '*' && typeof object[eventKey] === 'object' && object[eventKey] !== target){
            if(targetIsObject){
                tracked.delete(target);
            }
            removeHandler(object, eventKey, handle, handler);
            trackObjects(eventName, tracked, handler, object, key, path);
            return;
        }

        if(eventKey === '*'){
            trackKeys(eventName, tracked, handler, object, key, path);
        }

        if(!tracked.has(object)){
            return;
        }

        if(key !== '**' || !path){
            handler(event, emitKey);
        }
    };

    addHandler(object, eventKey, handle, handler);

    if(!targetIsObject){
        return;
    }

    tracked.add(target);

    if(!path){
        return;
    }

    var rootAndRest = leftAndRest(path),
        root,
        rest;

    if(!Array.isArray(rootAndRest)){
        root = rootAndRest;
    }else{
        root = rootAndRest[0];
        rest = rootAndRest[1];

        // If the root is '.', watch for events on *
        if(root === '.'){
            root = '*';
        }
    }

    if(targetIsObject && isWildcardKey(root)){
        trackKeys(eventName, tracked, handler, target, root, rest);
    }

    trackObjects(eventName, tracked, handler, target, root, rest);
}

function emitForEnti(trackedPaths, trackedObjectPaths, eventName, emitKey, event, enti){
    var emitSet = emitKey.get(eventName);
    if(!emitSet){
        emitSet = setPool.get();
        emitKey.set(eventName, emitSet);
    }

    if(emitSet.has(enti)){
        return;
    }

    if(!trackedPaths.trackedObjects.has(enti._model)){
        trackedPaths.entis.delete(enti);
        if(trackedPaths.entis.size === 0){
            delete trackedObjectPaths[eventName];
        }
        return;
    }

    emitSet.add(enti);

    var targetKey = getTargetKey(eventName),
        value = isWildcardPath(targetKey) ? undefined : enti.get(targetKey);

    enti.emit(eventName, value, event);
}

var trackedEvents = new WeakMap();
function createHandler(enti, trackedObjectPaths, trackedPaths, eventName){
    return function(event, emitKey){
        trackedPaths.entis.forEach(emitForEnti.bind(null, trackedPaths, trackedObjectPaths, eventName, emitKey, event));
    };
}

var internalEvents = ['newListener', 'attach', 'detached', 'destroy'];
function isInternalEvent(enti, eventName){
    return ~internalEvents.indexOf(eventName) &&
        enti._events &&
        enti._events[eventName] &&
        (!Array.isArray(enti._events[eventName]) || enti._events[eventName].length === 1);
}

function trackPath(enti, eventName){
    if(isInternalEvent(enti, eventName)){
        return;
    }

    var object = enti._model,
        trackedObjectPaths = trackedEvents.get(object);

    if(!trackedObjectPaths){
        trackedObjectPaths = {};
        trackedEvents.set(object, trackedObjectPaths);
    }

    var trackedPaths = trackedObjectPaths[eventName];

    if(!trackedPaths){
        trackedPaths = {
            entis: setPool.get(),
            trackedObjects: new WeakSet()
        };
        trackedObjectPaths[eventName] = trackedPaths;
    }else if(trackedPaths.entis.has(enti)){
        return;
    }

    trackedPaths.entis.add(enti);

    var handler = createHandler(enti, trackedObjectPaths, trackedPaths, eventName);

    trackObjects(eventName, trackedPaths.trackedObjects, handler, {model:object}, 'model', eventName);
}

function trackPaths(enti){
    if(!enti._events || !enti._model){
        return;
    }

    for(var key in enti._events){
        trackPath(enti, key);
    }
    modifiedEnties.delete(enti);
}

function emitEvent(object, key, value, emitKey){

    modifiedEnties.forEach(trackPaths);

    var trackedKeys = trackedObjects.get(object);

    if(!trackedKeys){
        return;
    }

    var event = {
        value: value,
        key: key,
        object: object
    };

    function emitForKey(handler){
        handler(event, emitKey);
    }

    if(trackedKeys[key]){
        trackedKeys[key].forEach(emitForKey);
    }

    if(trackedKeys['*']){
        trackedKeys['*'].forEach(emitForKey);
    }
}

function emit(events){
    var emitKey = emitKeyPool.get();

    events.forEach(function(event){
        emitEvent(event[0], event[1], event[2], emitKey);
    });

    emitKeyPool.dispose(emitKey);
}

function onNewListener(){
    modifiedEnties.add(this);
}

function modelRemove(model, events, key){
    if(Array.isArray(model)){
        model.splice(key, 1);
        events.push([model, 'length', model.length]);
    }else{
        delete model[key];
        events.push([model, key]);
    }
}

function Enti(model){
    if(!(this instanceof Enti)){
        return new Enti(model);
    }

    var detached = model === false;

    if(!model || (typeof model !== 'object' && typeof model !== 'function')){
        model = {};
    }

    if(detached){
        this._model = {};
    }else{
        this.attach(model);
    }

    this.on('newListener', onNewListener);
}
Enti.emit = function(model, key, value){
    if(!(typeof model === 'object' || typeof model === 'function')){
        return;
    }

    emit([[model, key, value]]);
};
Enti.get = function(model, key){
    if(!model || typeof model !== 'object'){
        return;
    }

    key = getTargetKey(key);

    if(key === '.'){
        return model;
    }


    var path = leftAndRest(key);
    if(Array.isArray(path)){
        return Enti.get(model[path[0]], path[1]);
    }

    return model[key];
};
Enti.set = function(model, key, value){
    if(!model || typeof model !== 'object'){
        return;
    }

    key = getTargetKey(key);

    var path = leftAndRest(key);
    if(Array.isArray(path)){
        return Enti.set(model[path[0]], path[1], value);
    }

    var original = model[key];

    if(typeof value !== 'object' && value === original){
        return;
    }

    var keysChanged = !(key in model);

    model[key] = value;

    var events = [[model, key, value]];

    if(keysChanged){
        if(Array.isArray(model)){
            events.push([model, 'length', model.length]);
        }
    }

    emit(events);
};
Enti.push = function(model, key, value){
    if(!model || typeof model !== 'object'){
        return;
    }

    var target;
    if(arguments.length < 3){
        value = key;
        key = '.';
        target = model;
    }else{
        var path = leftAndRest(key);
        if(Array.isArray(path)){
            return Enti.push(model[path[0]], path[1], value);
        }

        target = model[key];
    }

    if(!Array.isArray(target)){
        throw new Error('The target is not an array.');
    }

    target.push(value);

    var events = [
        [target, target.length-1, value],
        [target, 'length', target.length]
    ];

    emit(events);
};
Enti.insert = function(model, key, value, index){
    if(!model || typeof model !== 'object'){
        return;
    }


    var target;
    if(arguments.length < 4){
        index = value;
        value = key;
        key = '.';
        target = model;
    }else{
        var path = leftAndRest(key);
        if(Array.isArray(path)){
            return Enti.insert(model[path[0]], path[1], value, index);
        }

        target = model[key];
    }

    if(!Array.isArray(target)){
        throw new Error('The target is not an array.');
    }

    target.splice(index, 0, value);

    var events = [
        [target, index, value],
        [target, 'length', target.length]
    ];

    emit(events);
};
Enti.remove = function(model, key, subKey){
    if(!model || typeof model !== 'object'){
        return;
    }

    var path = leftAndRest(key);
    if(Array.isArray(path)){
        return Enti.remove(model[path[0]], path[1], subKey);
    }

    // Remove a key off of an object at 'key'
    if(subKey != null){
        Enti.remove(model[key], subKey);
        return;
    }

    if(key === '.'){
        throw new Error('. (self) is not a valid key to remove');
    }

    var events = [];

    modelRemove(model, events, key);

    emit(events);
};
Enti.move = function(model, key, index){
    if(!model || typeof model !== 'object'){
        return;
    }

    var path = leftAndRest(key);
    if(Array.isArray(path)){
        return Enti.move(model[path[0]], path[1], index);
    }

    if(key === index){
        return;
    }

    if(!Array.isArray(model)){
        throw new Error('The model is not an array.');
    }

    var item = model[key];

    model.splice(key, 1);

    model.splice(index, 0, item);

    emit([[model, index, item]]);
};
Enti.update = function(model, key, value, options){
    if(!model || typeof model !== 'object'){
        return;
    }

    var target,
        isArray = Array.isArray(value);

    var events = [],
        updatedObjects = new WeakSet();

    if(typeof key === 'object'){
        options = value;
        value = key;
        key = '.';
        target = model;
    }else{
        var path = leftAndRest(key);
        if(Array.isArray(path)){
            return Enti.update(model[path[0]], path[1], value);
        }

        if(!(key in model)){
            model[key] = isArray ? [] : {};
            events.push([model, key, target]);
        }

        target = model[key];
    }

    if(typeof value !== 'object'){
        throw new Error('The value is not an object.');
    }

    if(typeof target !== 'object'){
        throw new Error('The target is not an object.');
    }

    function updateTarget(target, value){
        for(var key in value){
            var currentValue = target[key];
            var updatedValue = value[key];

            if(
                updatedValue &&
                typeof updatedValue === 'object' &&
                currentValue instanceof Object &&
                !updatedObjects.has(currentValue) &&
                !(currentValue instanceof Date)
            ){
                updatedObjects.add(currentValue);
                updateTarget(currentValue, updatedValue);
                continue;
            }

            target[key] = updatedValue;
            events.push([target, key, updatedValue]);
        }

        if(options && options.strategy === 'morph'){
            for(var key in target){
                if(!(key in value)){
                    modelRemove(target, events, key);
                }
            }
        }

        if(Array.isArray(target)){
            events.push([target, 'length', target.length]);
        }
    }

    updateTarget(target, value);

    emit(events);
};
Enti.prototype = Object.create(EventEmitter.prototype);
Enti.prototype._maxListeners = 1000;
Enti.prototype.constructor = Enti;
Enti.prototype.attach = function(model){
    if(this._model === model){
        return;
    }

    this.detach();

    if(model && !isInstance(model)){
        throw new Error('Entis may only be attached to an object, or null/undefined');
    }

    modifiedEnties.add(this);
    this._attached = true;
    this._model = model;
    this.emit('attach', model);
};
Enti.prototype.detach = function(){
    if(!this._attached){
        return;
    }
    modifiedEnties.delete(this);

    this._model = {};
    this._attached = false;
    this.emit('detach');
};
Enti.prototype.destroy = function(){
    this.detach();
    this.emit('destroy');
    this._events = undefined;
};
Enti.prototype.get = function(key){
    return Enti.get(this._model, key);
};

Enti.prototype.set = function(key, value){
    return Enti.set(this._model, key, value);
};

Enti.prototype.push = function(key, value){
    return Enti.push.apply(null, [this._model].concat(toArray(arguments)));
};

Enti.prototype.insert = function(key, value, index){
    return Enti.insert.apply(null, [this._model].concat(toArray(arguments)));
};

Enti.prototype.remove = function(key, subKey){
    return Enti.remove.apply(null, [this._model].concat(toArray(arguments)));
};

Enti.prototype.move = function(key, index){
    return Enti.move.apply(null, [this._model].concat(toArray(arguments)));
};

Enti.prototype.update = function(key, index){
    return Enti.update.apply(null, [this._model].concat(toArray(arguments)));
};
Enti.prototype.isAttached = function(){
    return this._attached;
};
Enti.prototype.attachedCount = function(){
    return modifiedEnties.size;
};

Enti.isEnti = function(target){
    return target && !!~globalState.instances.indexOf(target.constructor);
};

Enti.store = function(target, key, value){
    if(arguments.length < 2){
        return Enti.get(target, key);
    }

    Enti.set(target, key, value);
};

Enti.create = function(handlers){
    var observer = new Enti();
    observer.handlers = handlers;

    Object.keys(handlers).forEach(function(path){
        observer.on(path, handlers[path])
    });

    return observer;
};

globalState.instances.push(Enti);

module.exports = Enti;

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"events":11,"is-instance":21}],20:[function(require,module,exports){
var EventEmitter = require('events').EventEmitter,
    functionEmitterPrototype = function(){};

for(var key in EventEmitter.prototype){
    functionEmitterPrototype[key] = EventEmitter.prototype[key];
}

module.exports = functionEmitterPrototype;
},{"events":11}],21:[function(require,module,exports){
module.exports = function(value){
    return value && typeof value === 'object' || typeof value === 'function';
};
},{}],22:[function(require,module,exports){
var getComponentConfig = require('./getComponentConfig');

module.exports = function setProperty(component, key, newPropertyConfig){
    var currentValue;

    var componentConfig = getComponentConfig(component);
    var componentPropertiesConfig = componentConfig.properties;

    if(!componentPropertiesConfig[key]){
        componentPropertiesConfig[key] = {
            onChange: value => { component[key] = value; }
        };

        Object.defineProperty(component, key, {
            get: function() {
                return currentValue;
            },
            set: function(newValue){
                // if(propertyConfig.transform){
                //     newValue = propertyConfig.transform(component, key, newValue, currentValue);
                // }
                currentValue = newValue;
                component.emit(key, currentValue);
            }
        });
    }

    var propertyConfig = componentPropertiesConfig[key];

    // if('transform' in newPropertyConfig){
    //     propertyConfig.transform = newPropertyConfig.transform;
    // }

    if('value' in newPropertyConfig){
        currentValue = newPropertyConfig.value;
        component[key] = currentValue;
    }

    if('emitter' in newPropertyConfig){
        if(propertyConfig.emitter){
            propertyConfig.emitter.removeListener('change', propertyConfig.onChange);
            if(propertyConfig.emitter.attach){
                component.removeListener('attach', propertyConfig.emitter.attach);
            }
        }

        propertyConfig.emitter = newPropertyConfig.emitter;

        if(!propertyConfig.emitter){
            return;
        }
        
        if(propertyConfig.emitter.attach){
            component.on('attach', propertyConfig.emitter.attach);
            component.on('detach', propertyConfig.emitter.detach);
        }

        if(typeof propertyConfig.emitter === 'function'){
            currentValue = propertyConfig.emitter();
        }

        propertyConfig.emitter.on('change', propertyConfig.onChange);
    }
}
},{"./getComponentConfig":15}]},{},[9]);
